#include "linearalgebra.h"

#include "../vector3d.h"

LinearAlgebra::LinearAlgebra()
{
}
