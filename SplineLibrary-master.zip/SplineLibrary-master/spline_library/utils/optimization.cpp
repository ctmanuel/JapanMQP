#include "optimization.h"

Optimization::Optimization()
{
}
